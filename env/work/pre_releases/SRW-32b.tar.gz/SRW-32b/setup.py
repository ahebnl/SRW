import os, sys, string, re
from glob import glob
#import numpy

import distutils
from distutils.core import setup, Extension

headers = glob (os.path.join ("Include","*.h") )
#header = headers + glob (os.path.join ("Include/numpy","*.h") )

setup (	name = "srwlpy", 
	version = "1.0",
	ext_modules = [Extension('srwlpy', 
				['srwlpy.cpp'],#,'libsrw.a'], 
				library_dirs  = ['.'],
				libraries     = ['srw','m','sfftw'],
				include_dirs  = ['include'],
				),
			]
	)

